import React from 'react';

const DriveLinkButton = () => {
  const handleButtonClick = () => {
    const driveLink = 'https://drive.google.com/file/d/your-file-id/view?usp=sharing';
    window.open(driveLink, '_blank');
  };

  return (
    <div>
      <p>Click the button to open the Google Drive link:</p>
      <button onClick={handleButtonClick}>Open Drive Link</button>
    </div>
  );
};

export default DriveLinkButton;
